/*
 *       APM_RC_.cpp - Radio Control Library for Ardupilot Mega. Arduino
 *       Code by Jordi Mu�oz and Jose Julio. DIYDrones.com
 *
 */
#include "APM_RC.h"

volatile uint32_t APM_RC_Class::_last_update;

