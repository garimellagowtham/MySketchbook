This implementation of DigitalWriteFast() and related functions is
based on the following code:

  http://code.google.com/p/digitalwritefast/

This code is available under the GNU General Public License version 3,
and was originally written by johnraines24@gmail.com

The code was imported into APM by Randy Mackay and Andrew Tridgell

